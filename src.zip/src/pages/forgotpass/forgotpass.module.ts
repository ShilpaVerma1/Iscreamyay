import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { ForgotpassPage } from './forgotpass';

@NgModule({
  declarations: [
    ForgotpassPage,
  ],

  exports: [
    ForgotpassPage
  ]
})
export class ForgotpassPageModule {}
