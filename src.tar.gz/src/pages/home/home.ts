import { Component } from '@angular/core';
import { NavController, Platform,MenuController} from 'ionic-angular';
import { FbPage } from '../fblog/fblog';
import { OneSignal } from 'ionic-native';
import { Network } from 'ionic-native';
import { Storage } from '@ionic/storage';

declare var window: any;
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [OneSignal]
})
export class HomePage {
  FbPage = FbPage;
dvcid:any;
dvctoken:any;
  constructor(public navCtrl: NavController,public menu:MenuController, public platform: Platform, private storage: Storage) {
 Network.onDisconnect().subscribe(() => {
      this.platform.ready().then(() => {
          window.plugins.toast.show("You are offline", "long", "center");
        });

    });
     Network.onConnect().subscribe(()=> {
      // this.platform.ready().then(() => {
      //    window.plugins.toast.show("You are online", "long", "center");
      //   });
     });

// one signal notification

            this.platform.ready().then(() => {
            OneSignal.startInit('862a0842-e625-439f-a3af-5a41c6a2ac1c', '115973810805'); // import APP ID and Project Number
            OneSignal.inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification);
            OneSignal.setSubscription(true);
            OneSignal.getIds().then((dviceid)=>{
            this.storage.set("deviceid", dviceid.userId);
            this.storage.set("devicetoken", dviceid.pushToken);
            });

            OneSignal.handleNotificationReceived().subscribe((data) => {
            });
            OneSignal.handleNotificationOpened().subscribe(() => {
            // handle opened here how you wish.
            });

            OneSignal.endInit();
            })

//
}
helloone(){
//     this.storage.get('devicetoken').then((devicetoken) => {
//   this.dvctoken = devicetoken;
//  if(this.dvctoken != null){
    this.navCtrl.push(FbPage,{
      //dvctokn:this.dvctoken
   // })
//   }else{
//     alert("Reopen your app");
//   }
})
 
}
ionViewDidEnter() {
    //to disable menu, or
    this.menu.enable(false);
  }

  ionViewWillLeave() {
    // to enable menu.
    this.menu.enable(true);
  }
}
