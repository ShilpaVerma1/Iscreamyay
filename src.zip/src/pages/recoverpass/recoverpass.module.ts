import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { RecoverpassPage } from './recoverpass';

@NgModule({
  declarations: [
    RecoverpassPage,
  ],
  exports: [
    RecoverpassPage
  ]
})
export class RecoverpassPageModule {}
